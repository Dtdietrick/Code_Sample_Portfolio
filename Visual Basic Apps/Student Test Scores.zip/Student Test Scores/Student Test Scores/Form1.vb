﻿Imports System.IO

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        StudentScoreInput()
    End Sub

    Const MAX_STUDENTS As Integer = 6
    Dim StuArray(MAX_STUDENTS) As StuData

    Sub StudentNameInput()
        StuArray(0).stuName = stu1Name.Text
        StuArray(1).stuName = stu2Name.Text
        StuArray(2).stuName = stu3Name.Text
        StuArray(3).stuName = stu4Name.Text
        StuArray(4).stuName = stu5Name.Text
        StuArray(5).stuName = stu6Name.Text

    End Sub

    Public Structure StuData
        Dim stuName As String
        Dim dblTestScores() As Double
        Dim dblAverage As Double
    End Structure
    Sub StudentScoreInput()

        For index = 0 To MAX_STUDENTS
            ReDim StuArray(index).dblTestScores(4)
        Next

        Try
            'Student One Input
            StuArray(0).dblTestScores(0) = IsValid(CDbl(Stu1Score1.Text))
            StuArray(0).dblTestScores(1) = IsValid(CDbl(Stu1Score2.Text))
            StuArray(0).dblTestScores(2) = IsValid(CDbl(Stu1Score3.Text))
            StuArray(0).dblTestScores(3) = IsValid(CDbl(Stu1Score4.Text))
            StuArray(0).dblTestScores(4) = IsValid(CDbl(Stu1Score5.Text))

            'Student Two Input
            StuArray(1).dblTestScores(0) = IsValid(CDbl(Stu2Score1.Text))
            StuArray(1).dblTestScores(1) = IsValid(CDbl(Stu2Score2.Text))
            StuArray(1).dblTestScores(2) = IsValid(CDbl(Stu2Score3.Text))
            StuArray(1).dblTestScores(3) = IsValid(CDbl(Stu2Score4.Text))
            StuArray(1).dblTestScores(4) = IsValid(CDbl(Stu2Score5.Text))

            'Student Three Input
            StuArray(2).dblTestScores(0) = IsValid(CDbl(Stu3Score1.Text))
            StuArray(2).dblTestScores(1) = IsValid(CDbl(Stu3Score2.Text))
            StuArray(2).dblTestScores(2) = IsValid(CDbl(Stu3Score3.Text))
            StuArray(2).dblTestScores(3) = IsValid(CDbl(Stu3Score4.Text))
            StuArray(2).dblTestScores(4) = IsValid(CDbl(Stu3Score5.Text))

            'Student Four Input
            StuArray(3).dblTestScores(0) = IsValid(CDbl(Stu4Score1.Text))
            StuArray(3).dblTestScores(1) = IsValid(CDbl(Stu4Score2.Text))
            StuArray(3).dblTestScores(2) = IsValid(CDbl(Stu4Score3.Text))
            StuArray(3).dblTestScores(3) = IsValid(CDbl(Stu4Score4.Text))
            StuArray(3).dblTestScores(4) = IsValid(CDbl(Stu4Score5.Text))

            'Student Five Input
            StuArray(4).dblTestScores(0) = IsValid(CDbl(Stu5Score1.Text))
            StuArray(4).dblTestScores(1) = IsValid(CDbl(Stu5Score2.Text))
            StuArray(4).dblTestScores(2) = IsValid(CDbl(Stu5Score3.Text))
            StuArray(4).dblTestScores(3) = IsValid(CDbl(Stu5Score4.Text))
            StuArray(4).dblTestScores(4) = IsValid(CDbl(Stu4Score5.Text))

            'Student Six Input
            StuArray(5).dblTestScores(0) = IsValid(CDbl(Stu6Score1.Text))
            StuArray(5).dblTestScores(1) = IsValid(CDbl(Stu6Score2.Text))
            StuArray(5).dblTestScores(2) = IsValid(CDbl(Stu6Score3.Text))
            StuArray(5).dblTestScores(3) = IsValid(CDbl(Stu6Score4.Text))
            StuArray(5).dblTestScores(4) = IsValid(CDbl(Stu6Score5.Text))

        Catch ex As Exception
            MessageBox.Show("Only Entries Between 1 and 100 are Valid")
        End Try

        Dim intStuOneList As New List(Of Integer)
        Dim intStuTwoList As New List(Of Integer)
        Dim intStuThreeList As New List(Of Integer)
        Dim intStuFourList As New List(Of Integer)
        Dim intStuFiveList As New List(Of Integer)
        Dim intStuSixList As New List(Of Integer)

        'Student One Average
        intStuOneList.AddRange(New Integer() {CInt(Stu1Score1.Text), CInt(Stu1Score2.Text), CInt(Stu1Score3.Text), CInt(Stu1Score4.Text), CInt(Stu1Score5.Text)})
        lblStu1Avg.Text = intStuOneList.DefaultIfEmpty().Average.ToString

        'Student Two Average
        intStuTwoList.AddRange(New Integer() {CInt(Stu2Score1.Text), CInt(Stu2Score2.Text), CInt(Stu2Score3.Text), CInt(Stu2Score4.Text), CInt(Stu2Score5.Text)})
        lblStu2Avg.Text = intStuTwoList.DefaultIfEmpty().Average.ToString

        'Student Three Average
        intStuThreeList.AddRange(New Integer() {CInt(Stu3Score1.Text), CInt(Stu3Score2.Text), CInt(Stu3Score3.Text), CInt(Stu3Score4.Text), CInt(Stu3Score5.Text)})
        lblStu3Avg.Text = intStuThreeList.DefaultIfEmpty().Average.ToString

        'Student Four Average
        intStuFourList.AddRange(New Integer() {CInt(Stu4Score1.Text), CInt(Stu4Score2.Text), CInt(Stu4Score3.Text), CInt(Stu4Score4.Text), CInt(Stu4Score5.Text)})
        lblStu4Avg.Text = intStuFourList.DefaultIfEmpty().Average.ToString

        'Student Five Average
        intStuFiveList.AddRange(New Integer() {CInt(Stu5Score1.Text), CInt(Stu5Score2.Text), CInt(Stu5Score3.Text), CInt(Stu5Score4.Text), CInt(Stu5Score5.Text)})
        lblStu5Avg.Text = intStuFiveList.DefaultIfEmpty().Average.ToString

        'Student Six Average
        intStuSixList.AddRange(New Integer() {CInt(Stu6Score1.Text), CInt(Stu6Score2.Text), CInt(Stu6Score3.Text), CInt(Stu6Score4.Text), CInt(Stu6Score5.Text)})
        lblStu6Avg.Text = intStuSixList.DefaultIfEmpty().Average.ToString
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Public Function IsValid(ByVal num As Integer) As Integer
        If num >= 0 And num <= 100 Then
            Return (num)
        Else
            Return ("error")

        End If

    End Function

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        Dim filePath As System.IO.StreamWriter
        filePath = My.Computer.FileSystem.OpenTextFileWriter("c:\temp\studentdata.txt", True)

        filePath.WriteLine("Student Grades and Totals")
        filePath.WriteLine("")

        'Student One
        filePath.WriteLine("Student One's Name: " & stu1Name.Text)
        filePath.WriteLine(stu1Name.Text & "'s Test One: " & Stu1Score1.Text)
        filePath.WriteLine(stu1Name.Text & "'s Test Two: " & Stu1Score2.Text)
        filePath.WriteLine(stu1Name.Text & "'s Test Three: " & Stu1Score3.Text)
        filePath.WriteLine(stu1Name.Text & "'s Test Four: " & Stu1Score4.Text)
        filePath.WriteLine(stu1Name.Text & "'s Test Five: " & Stu1Score5.Text)
        filePath.WriteLine(stu1Name.Text & "'s Avg: " & lblStu1Avg.Text)
        filePath.WriteLine("")

        'Student Two
        filePath.WriteLine("Student Two's Name: " & stu2Name.Text)
        filePath.WriteLine(stu2Name.Text & "'s Test One: " & Stu2Score1.Text)
        filePath.WriteLine(stu2Name.Text & "'s Test Two: " & Stu2Score2.Text)
        filePath.WriteLine(stu2Name.Text & "'s Test Three: " & Stu2Score3.Text)
        filePath.WriteLine(stu2Name.Text & "'s Test Four: " & Stu2Score4.Text)
        filePath.WriteLine(stu2Name.Text & "'s Test Five: " & Stu2Score5.Text)
        filePath.WriteLine(stu2Name.Text & "'s Avg: " & lblStu2Avg.Text)
        filePath.WriteLine("")

        'Student Three
        filePath.WriteLine("Student Three's Name: " & stu3Name.Text)
        filePath.WriteLine(stu3Name.Text & "'s Test One: " & Stu3Score1.Text)
        filePath.WriteLine(stu3Name.Text & "'s Test Two: " & Stu3Score2.Text)
        filePath.WriteLine(stu3Name.Text & "'s Test Three: " & Stu3Score3.Text)
        filePath.WriteLine(stu3Name.Text & "'s Test Four: " & Stu3Score4.Text)
        filePath.WriteLine(stu3Name.Text & "'s Test Five: " & Stu3Score5.Text)
        filePath.WriteLine(stu3Name.Text & "'s Avg: " & lblStu3Avg.Text)
        filePath.WriteLine("")

        'Student Four
        filePath.WriteLine("Student Four's Name: " & stu4Name.Text)
        filePath.WriteLine(stu4Name.Text & "'s Test One: " & Stu4Score1.Text)
        filePath.WriteLine(stu4Name.Text & "'s Test Two: " & Stu4Score2.Text)
        filePath.WriteLine(stu4Name.Text & "'s Test Three: " & Stu4Score3.Text)
        filePath.WriteLine(stu4Name.Text & "'s Test Four: " & Stu4Score4.Text)
        filePath.WriteLine(stu4Name.Text & "'s Test Five: " & Stu4Score5.Text)
        filePath.WriteLine(stu4Name.Text & "'s Avg: " & lblStu4Avg.Text)
        filePath.WriteLine("")

        'Student Five
        filePath.WriteLine("Student Five's Name: " & stu5Name.Text)
        filePath.WriteLine(stu5Name.Text & "'s Test One: " & Stu5Score1.Text)
        filePath.WriteLine(stu5Name.Text & "'s Test Two: " & Stu5Score2.Text)
        filePath.WriteLine(stu5Name.Text & "'s Test Three: " & Stu5Score3.Text)
        filePath.WriteLine(stu5Name.Text & "'s Test Four: " & Stu5Score4.Text)
        filePath.WriteLine(stu5Name.Text & "'s Test Five: " & Stu5Score5.Text)
        filePath.WriteLine(stu5Name.Text & "'s Avg: " & lblStu5Avg.Text)
        filePath.WriteLine("")


        'Student Six
        filePath.WriteLine("Student Six's Name: " & stu6Name.Text)
        filePath.WriteLine(stu6Name.Text & "'s Test One: " & Stu6Score1.Text)
        filePath.WriteLine(stu6Name.Text & "'s Test Two: " & Stu6Score2.Text)
        filePath.WriteLine(stu6Name.Text & "'s Test Three: " & Stu6Score3.Text)
        filePath.WriteLine(stu6Name.Text & "'s Test Four: " & Stu6Score4.Text)
        filePath.WriteLine(stu6Name.Text & "'s Test Five: " & Stu6Score5.Text)
        filePath.WriteLine(stu6Name.Text & "'s Avg: " & lblStu6Avg.Text)
        filePath.WriteLine("")

        filePath.Close()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        Dim psi As New ProcessStartInfo

        psi.UseShellExecute = True

        psi.Verb = "print"

        psi.WindowStyle = ProcessWindowStyle.Hidden

        psi.FileName = "c:\temp\studentdata.txt"

        Process.Start(psi)

    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles openFile.Click
        Dim stuDataFile As String = "c:\temp\studentdata.txt"
        Dim strFileContents As String
        Dim objReader As New System.IO.StreamReader(stuDataFile)
        strFileContents = objReader.ReadToEnd
        MessageBox.Show(strFileContents, "Student Data")
        objReader.Close()

    End Sub
End Class
