﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblStu6Avg = New System.Windows.Forms.TextBox()
        Me.lblStu5Avg = New System.Windows.Forms.TextBox()
        Me.lblStu4Avg = New System.Windows.Forms.TextBox()
        Me.lblStu3Avg = New System.Windows.Forms.TextBox()
        Me.lblStu2Avg = New System.Windows.Forms.TextBox()
        Me.lblStu1Avg = New System.Windows.Forms.TextBox()
        Me.Stu6Score5 = New System.Windows.Forms.TextBox()
        Me.Stu4Score4 = New System.Windows.Forms.TextBox()
        Me.Stu5Score4 = New System.Windows.Forms.TextBox()
        Me.Stu6Score4 = New System.Windows.Forms.TextBox()
        Me.Stu4Score5 = New System.Windows.Forms.TextBox()
        Me.Stu5Score5 = New System.Windows.Forms.TextBox()
        Me.Stu6Score3 = New System.Windows.Forms.TextBox()
        Me.Stu5Score3 = New System.Windows.Forms.TextBox()
        Me.Stu6Score2 = New System.Windows.Forms.TextBox()
        Me.Stu5Score2 = New System.Windows.Forms.TextBox()
        Me.Stu6Score1 = New System.Windows.Forms.TextBox()
        Me.Stu5Score1 = New System.Windows.Forms.TextBox()
        Me.Stu4Score3 = New System.Windows.Forms.TextBox()
        Me.Stu4Score2 = New System.Windows.Forms.TextBox()
        Me.Stu4Score1 = New System.Windows.Forms.TextBox()
        Me.Stu3Score4 = New System.Windows.Forms.TextBox()
        Me.Stu3Score5 = New System.Windows.Forms.TextBox()
        Me.Stu3Score3 = New System.Windows.Forms.TextBox()
        Me.Stu3Score2 = New System.Windows.Forms.TextBox()
        Me.Stu3Score1 = New System.Windows.Forms.TextBox()
        Me.Stu2Score5 = New System.Windows.Forms.TextBox()
        Me.Stu2Score4 = New System.Windows.Forms.TextBox()
        Me.Stu2Score3 = New System.Windows.Forms.TextBox()
        Me.Stu2Score2 = New System.Windows.Forms.TextBox()
        Me.Stu2Score1 = New System.Windows.Forms.TextBox()
        Me.Stu1Score5 = New System.Windows.Forms.TextBox()
        Me.Stu1Score4 = New System.Windows.Forms.TextBox()
        Me.Stu1Score3 = New System.Windows.Forms.TextBox()
        Me.Stu1Score2 = New System.Windows.Forms.TextBox()
        Me.Stu1Score1 = New System.Windows.Forms.TextBox()
        Me.stu6Name = New System.Windows.Forms.TextBox()
        Me.stu2Name = New System.Windows.Forms.TextBox()
        Me.stu3Name = New System.Windows.Forms.TextBox()
        Me.stu4Name = New System.Windows.Forms.TextBox()
        Me.stu5Name = New System.Windows.Forms.TextBox()
        Me.stu1Name = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.openFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblStu6Avg)
        Me.GroupBox1.Controls.Add(Me.lblStu5Avg)
        Me.GroupBox1.Controls.Add(Me.lblStu4Avg)
        Me.GroupBox1.Controls.Add(Me.lblStu3Avg)
        Me.GroupBox1.Controls.Add(Me.lblStu2Avg)
        Me.GroupBox1.Controls.Add(Me.lblStu1Avg)
        Me.GroupBox1.Controls.Add(Me.Stu6Score5)
        Me.GroupBox1.Controls.Add(Me.Stu4Score4)
        Me.GroupBox1.Controls.Add(Me.Stu5Score4)
        Me.GroupBox1.Controls.Add(Me.Stu6Score4)
        Me.GroupBox1.Controls.Add(Me.Stu4Score5)
        Me.GroupBox1.Controls.Add(Me.Stu5Score5)
        Me.GroupBox1.Controls.Add(Me.Stu6Score3)
        Me.GroupBox1.Controls.Add(Me.Stu5Score3)
        Me.GroupBox1.Controls.Add(Me.Stu6Score2)
        Me.GroupBox1.Controls.Add(Me.Stu5Score2)
        Me.GroupBox1.Controls.Add(Me.Stu6Score1)
        Me.GroupBox1.Controls.Add(Me.Stu5Score1)
        Me.GroupBox1.Controls.Add(Me.Stu4Score3)
        Me.GroupBox1.Controls.Add(Me.Stu4Score2)
        Me.GroupBox1.Controls.Add(Me.Stu4Score1)
        Me.GroupBox1.Controls.Add(Me.Stu3Score4)
        Me.GroupBox1.Controls.Add(Me.Stu3Score5)
        Me.GroupBox1.Controls.Add(Me.Stu3Score3)
        Me.GroupBox1.Controls.Add(Me.Stu3Score2)
        Me.GroupBox1.Controls.Add(Me.Stu3Score1)
        Me.GroupBox1.Controls.Add(Me.Stu2Score5)
        Me.GroupBox1.Controls.Add(Me.Stu2Score4)
        Me.GroupBox1.Controls.Add(Me.Stu2Score3)
        Me.GroupBox1.Controls.Add(Me.Stu2Score2)
        Me.GroupBox1.Controls.Add(Me.Stu2Score1)
        Me.GroupBox1.Controls.Add(Me.Stu1Score5)
        Me.GroupBox1.Controls.Add(Me.Stu1Score4)
        Me.GroupBox1.Controls.Add(Me.Stu1Score3)
        Me.GroupBox1.Controls.Add(Me.Stu1Score2)
        Me.GroupBox1.Controls.Add(Me.Stu1Score1)
        Me.GroupBox1.Controls.Add(Me.stu6Name)
        Me.GroupBox1.Controls.Add(Me.stu2Name)
        Me.GroupBox1.Controls.Add(Me.stu3Name)
        Me.GroupBox1.Controls.Add(Me.stu4Name)
        Me.GroupBox1.Controls.Add(Me.stu5Name)
        Me.GroupBox1.Controls.Add(Me.stu1Name)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(599, 263)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Data"
        '
        'lblStu6Avg
        '
        Me.lblStu6Avg.Location = New System.Drawing.Point(532, 209)
        Me.lblStu6Avg.Name = "lblStu6Avg"
        Me.lblStu6Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu6Avg.TabIndex = 43
        '
        'lblStu5Avg
        '
        Me.lblStu5Avg.Location = New System.Drawing.Point(532, 182)
        Me.lblStu5Avg.Name = "lblStu5Avg"
        Me.lblStu5Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu5Avg.TabIndex = 42
        '
        'lblStu4Avg
        '
        Me.lblStu4Avg.Location = New System.Drawing.Point(532, 156)
        Me.lblStu4Avg.Name = "lblStu4Avg"
        Me.lblStu4Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu4Avg.TabIndex = 41
        '
        'lblStu3Avg
        '
        Me.lblStu3Avg.Location = New System.Drawing.Point(532, 130)
        Me.lblStu3Avg.Name = "lblStu3Avg"
        Me.lblStu3Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu3Avg.TabIndex = 40
        '
        'lblStu2Avg
        '
        Me.lblStu2Avg.Location = New System.Drawing.Point(532, 104)
        Me.lblStu2Avg.Name = "lblStu2Avg"
        Me.lblStu2Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu2Avg.TabIndex = 39
        '
        'lblStu1Avg
        '
        Me.lblStu1Avg.Location = New System.Drawing.Point(532, 78)
        Me.lblStu1Avg.Name = "lblStu1Avg"
        Me.lblStu1Avg.Size = New System.Drawing.Size(36, 20)
        Me.lblStu1Avg.TabIndex = 38
        '
        'Stu6Score5
        '
        Me.Stu6Score5.Location = New System.Drawing.Point(416, 208)
        Me.Stu6Score5.Name = "Stu6Score5"
        Me.Stu6Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu6Score5.TabIndex = 10
        '
        'Stu4Score4
        '
        Me.Stu4Score4.Location = New System.Drawing.Point(374, 156)
        Me.Stu4Score4.Name = "Stu4Score4"
        Me.Stu4Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu4Score4.TabIndex = 37
        '
        'Stu5Score4
        '
        Me.Stu5Score4.Location = New System.Drawing.Point(374, 182)
        Me.Stu5Score4.Name = "Stu5Score4"
        Me.Stu5Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu5Score4.TabIndex = 36
        '
        'Stu6Score4
        '
        Me.Stu6Score4.Location = New System.Drawing.Point(374, 208)
        Me.Stu6Score4.Name = "Stu6Score4"
        Me.Stu6Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu6Score4.TabIndex = 35
        '
        'Stu4Score5
        '
        Me.Stu4Score5.Location = New System.Drawing.Point(416, 156)
        Me.Stu4Score5.Name = "Stu4Score5"
        Me.Stu4Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu4Score5.TabIndex = 34
        '
        'Stu5Score5
        '
        Me.Stu5Score5.Location = New System.Drawing.Point(416, 182)
        Me.Stu5Score5.Name = "Stu5Score5"
        Me.Stu5Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu5Score5.TabIndex = 33
        '
        'Stu6Score3
        '
        Me.Stu6Score3.Location = New System.Drawing.Point(332, 208)
        Me.Stu6Score3.Name = "Stu6Score3"
        Me.Stu6Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu6Score3.TabIndex = 32
        '
        'Stu5Score3
        '
        Me.Stu5Score3.Location = New System.Drawing.Point(332, 182)
        Me.Stu5Score3.Name = "Stu5Score3"
        Me.Stu5Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu5Score3.TabIndex = 31
        '
        'Stu6Score2
        '
        Me.Stu6Score2.Location = New System.Drawing.Point(290, 209)
        Me.Stu6Score2.Name = "Stu6Score2"
        Me.Stu6Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu6Score2.TabIndex = 30
        '
        'Stu5Score2
        '
        Me.Stu5Score2.Location = New System.Drawing.Point(290, 182)
        Me.Stu5Score2.Name = "Stu5Score2"
        Me.Stu5Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu5Score2.TabIndex = 29
        '
        'Stu6Score1
        '
        Me.Stu6Score1.Location = New System.Drawing.Point(248, 208)
        Me.Stu6Score1.Name = "Stu6Score1"
        Me.Stu6Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu6Score1.TabIndex = 28
        '
        'Stu5Score1
        '
        Me.Stu5Score1.Location = New System.Drawing.Point(248, 182)
        Me.Stu5Score1.Name = "Stu5Score1"
        Me.Stu5Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu5Score1.TabIndex = 27
        '
        'Stu4Score3
        '
        Me.Stu4Score3.Location = New System.Drawing.Point(332, 156)
        Me.Stu4Score3.Name = "Stu4Score3"
        Me.Stu4Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu4Score3.TabIndex = 26
        '
        'Stu4Score2
        '
        Me.Stu4Score2.Location = New System.Drawing.Point(290, 156)
        Me.Stu4Score2.Name = "Stu4Score2"
        Me.Stu4Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu4Score2.TabIndex = 25
        '
        'Stu4Score1
        '
        Me.Stu4Score1.Location = New System.Drawing.Point(248, 156)
        Me.Stu4Score1.Name = "Stu4Score1"
        Me.Stu4Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu4Score1.TabIndex = 24
        '
        'Stu3Score4
        '
        Me.Stu3Score4.Location = New System.Drawing.Point(374, 130)
        Me.Stu3Score4.Name = "Stu3Score4"
        Me.Stu3Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu3Score4.TabIndex = 23
        '
        'Stu3Score5
        '
        Me.Stu3Score5.Location = New System.Drawing.Point(416, 130)
        Me.Stu3Score5.Name = "Stu3Score5"
        Me.Stu3Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu3Score5.TabIndex = 22
        '
        'Stu3Score3
        '
        Me.Stu3Score3.Location = New System.Drawing.Point(332, 130)
        Me.Stu3Score3.Name = "Stu3Score3"
        Me.Stu3Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu3Score3.TabIndex = 21
        '
        'Stu3Score2
        '
        Me.Stu3Score2.Location = New System.Drawing.Point(290, 130)
        Me.Stu3Score2.Name = "Stu3Score2"
        Me.Stu3Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu3Score2.TabIndex = 20
        '
        'Stu3Score1
        '
        Me.Stu3Score1.Location = New System.Drawing.Point(248, 130)
        Me.Stu3Score1.Name = "Stu3Score1"
        Me.Stu3Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu3Score1.TabIndex = 19
        '
        'Stu2Score5
        '
        Me.Stu2Score5.Location = New System.Drawing.Point(416, 104)
        Me.Stu2Score5.Name = "Stu2Score5"
        Me.Stu2Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu2Score5.TabIndex = 18
        '
        'Stu2Score4
        '
        Me.Stu2Score4.Location = New System.Drawing.Point(374, 104)
        Me.Stu2Score4.Name = "Stu2Score4"
        Me.Stu2Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu2Score4.TabIndex = 17
        '
        'Stu2Score3
        '
        Me.Stu2Score3.Location = New System.Drawing.Point(332, 104)
        Me.Stu2Score3.Name = "Stu2Score3"
        Me.Stu2Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu2Score3.TabIndex = 16
        '
        'Stu2Score2
        '
        Me.Stu2Score2.Location = New System.Drawing.Point(290, 104)
        Me.Stu2Score2.Name = "Stu2Score2"
        Me.Stu2Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu2Score2.TabIndex = 15
        '
        'Stu2Score1
        '
        Me.Stu2Score1.Location = New System.Drawing.Point(248, 104)
        Me.Stu2Score1.Name = "Stu2Score1"
        Me.Stu2Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu2Score1.TabIndex = 14
        '
        'Stu1Score5
        '
        Me.Stu1Score5.Location = New System.Drawing.Point(416, 78)
        Me.Stu1Score5.Name = "Stu1Score5"
        Me.Stu1Score5.Size = New System.Drawing.Size(36, 20)
        Me.Stu1Score5.TabIndex = 13
        '
        'Stu1Score4
        '
        Me.Stu1Score4.Location = New System.Drawing.Point(374, 78)
        Me.Stu1Score4.Name = "Stu1Score4"
        Me.Stu1Score4.Size = New System.Drawing.Size(36, 20)
        Me.Stu1Score4.TabIndex = 12
        '
        'Stu1Score3
        '
        Me.Stu1Score3.Location = New System.Drawing.Point(332, 78)
        Me.Stu1Score3.Name = "Stu1Score3"
        Me.Stu1Score3.Size = New System.Drawing.Size(36, 20)
        Me.Stu1Score3.TabIndex = 11
        '
        'Stu1Score2
        '
        Me.Stu1Score2.Location = New System.Drawing.Point(290, 78)
        Me.Stu1Score2.Name = "Stu1Score2"
        Me.Stu1Score2.Size = New System.Drawing.Size(36, 20)
        Me.Stu1Score2.TabIndex = 10
        '
        'Stu1Score1
        '
        Me.Stu1Score1.Location = New System.Drawing.Point(248, 78)
        Me.Stu1Score1.Name = "Stu1Score1"
        Me.Stu1Score1.Size = New System.Drawing.Size(36, 20)
        Me.Stu1Score1.TabIndex = 9
        '
        'stu6Name
        '
        Me.stu6Name.Location = New System.Drawing.Point(25, 208)
        Me.stu6Name.Name = "stu6Name"
        Me.stu6Name.Size = New System.Drawing.Size(166, 20)
        Me.stu6Name.TabIndex = 8
        '
        'stu2Name
        '
        Me.stu2Name.Location = New System.Drawing.Point(25, 104)
        Me.stu2Name.Name = "stu2Name"
        Me.stu2Name.Size = New System.Drawing.Size(166, 20)
        Me.stu2Name.TabIndex = 7
        '
        'stu3Name
        '
        Me.stu3Name.Location = New System.Drawing.Point(25, 130)
        Me.stu3Name.Name = "stu3Name"
        Me.stu3Name.Size = New System.Drawing.Size(166, 20)
        Me.stu3Name.TabIndex = 6
        '
        'stu4Name
        '
        Me.stu4Name.Location = New System.Drawing.Point(25, 156)
        Me.stu4Name.Name = "stu4Name"
        Me.stu4Name.Size = New System.Drawing.Size(166, 20)
        Me.stu4Name.TabIndex = 5
        '
        'stu5Name
        '
        Me.stu5Name.Location = New System.Drawing.Point(25, 182)
        Me.stu5Name.Name = "stu5Name"
        Me.stu5Name.Size = New System.Drawing.Size(166, 20)
        Me.stu5Name.TabIndex = 4
        '
        'stu1Name
        '
        Me.stu1Name.Location = New System.Drawing.Point(25, 78)
        Me.stu1Name.Name = "stu1Name"
        Me.stu1Name.Size = New System.Drawing.Size(166, 20)
        Me.stu1Name.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(308, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Test Scores"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(529, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Average"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(513, 329)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 35)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Calculate" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Averages"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ReportToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(644, 24)
        Me.MenuStrip1.TabIndex = 45
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem, Me.openFile, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'openFile
        '
        Me.openFile.Name = "openFile"
        Me.openFile.Size = New System.Drawing.Size(180, 22)
        Me.openFile.Text = "Open"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintToolStripMenuItem})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.PrintToolStripMenuItem.Text = "Print"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 381)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblStu6Avg As TextBox
    Friend WithEvents lblStu5Avg As TextBox
    Friend WithEvents lblStu4Avg As TextBox
    Friend WithEvents lblStu3Avg As TextBox
    Friend WithEvents lblStu2Avg As TextBox
    Friend WithEvents lblStu1Avg As TextBox
    Friend WithEvents Stu6Score5 As TextBox
    Friend WithEvents Stu4Score4 As TextBox
    Friend WithEvents Stu5Score4 As TextBox
    Friend WithEvents Stu6Score4 As TextBox
    Friend WithEvents Stu4Score5 As TextBox
    Friend WithEvents Stu5Score5 As TextBox
    Friend WithEvents Stu6Score3 As TextBox
    Friend WithEvents Stu5Score3 As TextBox
    Friend WithEvents Stu6Score2 As TextBox
    Friend WithEvents Stu5Score2 As TextBox
    Friend WithEvents Stu6Score1 As TextBox
    Friend WithEvents Stu5Score1 As TextBox
    Friend WithEvents Stu4Score3 As TextBox
    Friend WithEvents Stu4Score2 As TextBox
    Friend WithEvents Stu4Score1 As TextBox
    Friend WithEvents Stu3Score4 As TextBox
    Friend WithEvents Stu3Score5 As TextBox
    Friend WithEvents Stu3Score3 As TextBox
    Friend WithEvents Stu3Score2 As TextBox
    Friend WithEvents Stu3Score1 As TextBox
    Friend WithEvents Stu2Score5 As TextBox
    Friend WithEvents Stu2Score4 As TextBox
    Friend WithEvents Stu2Score3 As TextBox
    Friend WithEvents Stu2Score2 As TextBox
    Friend WithEvents Stu2Score1 As TextBox
    Friend WithEvents Stu1Score5 As TextBox
    Friend WithEvents Stu1Score4 As TextBox
    Friend WithEvents Stu1Score3 As TextBox
    Friend WithEvents Stu1Score2 As TextBox
    Friend WithEvents Stu1Score1 As TextBox
    Friend WithEvents stu6Name As TextBox
    Friend WithEvents stu2Name As TextBox
    Friend WithEvents stu3Name As TextBox
    Friend WithEvents stu4Name As TextBox
    Friend WithEvents stu5Name As TextBox
    Friend WithEvents stu1Name As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents openFile As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
End Class
