﻿Public Class Form1

    Dim objRectangle As Rectangle
    Dim objCarpet As Carpet
    Dim validLength As Boolean = False
    Dim validPrice As Boolean = False
    Dim validWidth As Boolean = False


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim totalCost As New Single
        objRectangle = New Rectangle()
        objCarpet = New Carpet()
        If (txtWidth.Text = "") Or (txtLength.Text = "") Or (txtColor.Text = "") Or
        (txtStyle.Text = "") Or (txtPrice.Text = "") Then
            MessageBox.Show("Please ensure all fields have been filled and try again")
        Else
            GetCarpetData(objCarpet)
            GetRectangleData(objRectangle)
        End If
        If validWidth And validLength And validPrice Then
            totalCost = objCarpet.Price * objRectangle.Area
            lblCost.Text = (totalCost).ToString("c")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtColor.Text = ""
        txtLength.Text = ""
        txtPrice.Text = ""
        txtStyle.Text = ""
        txtWidth.Text = ""
        lblArea.Text = ""
        lblCost.Text = ""
        txtColor.Focus()
    End Sub

    Sub GetCarpetData(objCarpet As Carpet)
        validPrice = False
        objCarpet.Color = txtColor.Text
        objCarpet.Style = txtStyle.Text
        Try
            If (CSng(txtPrice.Text) >= 0) Then
                objCarpet.Price = CSng(txtPrice.Text)
                validPrice = True
            Else
                MessageBox.Show("Enter Positive Number for Price")
                txtPrice.Text = ""
                validPrice = False
            End If
        Catch ex As Exception
            MessageBox.Show("Enter positive number")
            validPrice = False
        End Try
    End Sub

    Sub GetRectangleData(objRectangle As Rectangle)
        validWidth = False
        validLength = False

        Try
            If (CSng(txtWidth.Text) > 0) Then
                objRectangle.Width = CSng(txtWidth.Text)
                validWidth = True
            Else
                MessageBox.Show("Enter Positive Number for Width")
                txtWidth.Text = ""
                validWidth = False
            End If
        Catch ex As Exception
            MessageBox.Show("Enter positive number")
            validWidth = False
        End Try

        Try
            If (CSng(txtLength.Text) > 0) Then
                objRectangle.Length = CSng(txtLength.Text)
                validLength = True
            Else
                MessageBox.Show("Enter Positive Number for Length")
                txtLength.Text = ""
                validLength = False
            End If
        Catch ex As Exception
            MessageBox.Show("Enter positive number")
            validLength = False
        End Try
        If validWidth And validLength Then
            lblArea.Text = CStr(objRectangle.Area)
        End If
    End Sub
End Class
Public Class Rectangle
    Private obj_Width As Single
    Private obj_Length As Single
    Private obj_Area As Single

    Public Sub New()
        obj_Width = 0
        obj_Length = 0
        obj_Area = 0
    End Sub

    Public Property Width As Single
        Get
            Return obj_Width
        End Get
        Set(value As Single)
            obj_Width = value
        End Set
    End Property

    Public Property Length As Single
        Get
            Return obj_Length
        End Get
        Set(value As Single)
            obj_Length = value
        End Set
    End Property

    ReadOnly Property Area As Single
        Get
            CalcArea()
            Return obj_Area
        End Get
    End Property
    Sub CalcArea()
        obj_Area = obj_Width * obj_Length
    End Sub
End Class

Public Class Carpet
    Private obj_Color As String
    Private obj_Style As String
    Private obj_Price As Decimal

    Public Sub New()
        obj_Color = ""
        obj_Style = ""
        obj_Price = 0.00
    End Sub

    Public Property Color As String
        Get
            Return obj_Color
        End Get
        Set(value As String)
            obj_Color = value
        End Set
    End Property

    Public Property Style As String
        Get
            Return obj_Style
        End Get
        Set(value As String)
            obj_Style = value
        End Set
    End Property

    Public Property Price As Decimal
        Get
            Return obj_Price
        End Get
        Set(value As Decimal)
            obj_Price = value
        End Set
    End Property
End Class

