﻿Public Class Form1
    Const ROOMS_PER_FLOOR As Integer = 30
    Const TOTAL_ROOMS As Integer = 240
    Dim intFloorNum As Integer
    Dim intNumRooms As Integer
    Dim intOccupiedRooms As Integer = 0
    Dim decOccupancyFloor As Decimal
    Dim decOverallOccupancy As Decimal
    Dim strOutput As String


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)
        coBoxFloor.Items.Clear()
        coBoxFloor.Items.Add("1")
        coBoxFloor.Items.Add("2")
        coBoxFloor.Items.Add("3")
        coBoxFloor.Items.Add("4")
        coBoxFloor.Items.Add("5")
        coBoxFloor.Items.Add("6")
        coBoxFloor.Items.Add("7")
        coBoxFloor.Items.Add("8")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        intFloorNum = CInt(coBoxFloor.SelectedItem)
        intNumRooms = CInt(txtNumRooms.Text)
        If intNumRooms >= 0 Or intNumRooms < 30 Then
            'Add the inputed data to the accumulator
            intOccupiedRooms += intNumRooms

            'Calculate the occupancy rate for this floor.
            decOccupancyFloor = CDec(intNumRooms / ROOMS_PER_FLOOR)

            'Start building the output string with the floor count.
            strOutput = "Floor " & (intFloorNum) & " "

            'Add the number of rooms occupied on this floor to the output string.
            strOutput &= ":Rooms Occupied= " & intNumRooms.ToString("n2")

            'Add the Occupancy Rate to the output string.
            strOutput &= ": Occupancy Rate=" & decOccupancyFloor.ToString("p")

            'Add the output string to the list box.
            lstBoxData.Items.Add(strOutput)
        Else
            'Warns the user if the inputed data for rooms occupied is less than 0 or greater than 30
            MessageBox.Show("Must select a number of rooms between 1 and 30.")
        End If
    End Sub
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        lblTotalRooms.Text = intOccupiedRooms.ToString
        decOverallOccupancy = CDec(intOccupiedRooms / TOTAL_ROOMS)
        lblTotalOccup.Text = decOverallOccupancy.ToString("P")


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblTotalRooms.Text = String.Empty
        lblTotalOccup.Text = String.Empty
        txtNumRooms.Text = String.Empty
        lstBoxData.Items.Clear()
        coBoxFloor.SelectedIndex = -1
    End Sub
End Class
